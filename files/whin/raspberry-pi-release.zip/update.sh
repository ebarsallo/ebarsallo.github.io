#!/bin/bash

### Parameters

DOWNLOAD_DIR=~/Downloads
CURRENT_DIR=$PWD
NOW=$(date +"%m%d%Y-%HH%MM%SS")
TMP_DIR="tmp-whin-${NOW}"

RELEASE_FN=lora-gateway.zip

### Routines


### Main

if [ "$1" != "" ]; then
    url=$1
else
    echo "Missing URL"
    exit 1
fi

cd ${DOWNLOAD_DIR}
mkdir ${TMP_DIR}
cd ${TMP_DIR}

# Download latest release
wget ${url} 
if [ $? != 0 ]; then
    echo "Release could not be  downloaded"
    exit 1
fi 

# Verify if file was downloaded
if [ ! -e  ${DOWNLOAD_DIR}/${TMP_DIR}/${RELEASE_FN} ]; then
    echo "${RELEASE_FN} not found."
    exit 1
fi

unzip ${RELEASE_FN}

echo "Success: ${PWD}"
exit 0
