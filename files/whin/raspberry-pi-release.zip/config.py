# Global variables with the info about each node in the WHIN network
global WHIN_NODES

# Array with readings collected from sensors (before sending them to the gateway)
global readings