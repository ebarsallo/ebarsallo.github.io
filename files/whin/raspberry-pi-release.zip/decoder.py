#!/usr/bin/env python3
import datetime

from enum import Enum
from prettytable import PrettyTable
from utils import get_nitrate, get_temp, get_mvolts, get_humidity, get_dielec, conv_2digits, conv_2digits_sign


class MessageType(Enum):
    """
    Enum with type of messages interchanged in the mesh network.
    """
    MESH_TYPE_UNKNOW = 0
    MESH_TYPE_DATA = 1                          # data transmission 
    MESH_TYPE_ACK = 2                           # acknowledge packet
    MESH_TYPE_FORWARD = 3
    MESH_TYPE_HELLO = 4
    MESH_TYPE_ROUTE_DISCOVERY_REQUEST = 5
    MESH_TYPE_ROUTE_DISCOVERY_RESPONSE = 6
    MESH_TYPE_ROUTE_FAILURE = 7
    MESH_TYPE_NULL = 8
    MESH_TYPE_RT_REPORT = 9
    MESH_TYPE_RT_GATHER = 10
    MESH_TYPE_RT_FORWARD = 11
    MESH_TYPE_SCHEDULE = 12
    MESH_TYPE_MASTER_COMMAND = 13

class MessageDecoder(object):
    """
    Decode message received. 
    """

    def __init__(self, logger, debug=True, log_mode=0):
        self.logger = logger
        self.debug = debug
        self.log_mode = log_mode

    def decode(self, 
               hexdata):

        type = int(hexdata[18:20], 16)
        if not self.__is_MessageType_valid(type):
            raise Exception('Message Type: {} not recognized'.format(type))

        message_type = MessageType(type)
        
        # convert data (hex) to an array of int
        data = self.__hexArray2IntArray(10, hexdata)

        # NOTE: WHIN v1 boards use 0 as TYPE_DATA in their firmware, while NEW boards 
        #       use 1.  For compatibility, 0 and 1 will be recognized as TYPE_DATA 

        # handles message according the type
        if message_type == MessageType.MESH_TYPE_UNKNOW:
            return self.__decode_data_old(data)

        elif message_type == MessageType.MESH_TYPE_DATA:
            return self.__decode_data(data)

        elif message_type == MessageType.MESH_TYPE_HELLO:
            return self.__decode_hello(data)

        elif message_type == MessageType.MESH_TYPE_ROUTE_DISCOVERY_REQUEST:
            return self.__decode_discovery_request(data)

        elif message_type == MessageType.MESH_TYPE_ROUTE_DISCOVERY_RESPONSE:
            return self.__decode_discovery_respose(data)

        elif message_type == MessageType.MESH_TYPE_RT_REPORT:
            return self.__decode_rt_report(data)

        elif message_type == MessageType.MESH_TYPE_RT_GATHER:
            return self.__decode_rt_gather(data)

        elif message_type == MessageType.MESH_TYPE_RT_FORWARD:
            return self.__decode_rt_forward(data)

        # Not implemented decoder
        elif message_type in MessageType.__members__.values():
            raise Exception('No decoder implemented for Message Type: {}'.format(message_type))
        
        # Message types not recognized
        else:
            raise Exception('The Message Type {} is not recognized'.format(message_type))

    # -------------------------------------------------------------------------------
    # Decoders method
    # -------------------------------------------------------------------------------

    def __decode_data_old(self, data):
        """
        Decode actual data (MESH_TYPE_DATA) or readings sent by WHIN board v1 
        specification nodes
        """

        # ===== Header =====
        
        # Previous Node (0)
        prv = data[0]
        # Source Node (2)
        src = data[2]
        # Message Type (4)
        typ = MessageType(data[4])
        # Message ID (5)
        mid = data[5]

        # ===== Data =====

        # Temperature (6,7)
        tmp = get_temp(data[6], data[7])
        # print("{}".format(tmp))
        # Nitrate (8,9,10)
        nit = get_nitrate(data[8], data[9], data[10])
        # Humidity (11,12)
        hum = get_humidity(data[11], data[12])
        # Battery mvolts (13,14)
        bat = get_mvolts(data[13], data[14])
        # Soil Sensors
        # Dielectric #1 (15, 16) 
        diel0 = conv_2digits(data[15], data[16])
        # Dielectric #2 (21, 22) 
        diel1 = conv_2digits(data[21], data[22])
        # Conductivity #1 (17, 18)
        cond0 = conv_2digits(data[17], data[18])
        # Conductivity #2 (23, 24)
        cond1 = conv_2digits(data[23], data[24])
        # Temperature #1 (19, 20)
        temp0 = conv_2digits(data[19], data[20])
        # Temperature #2 (25, 26)
        temp1 = conv_2digits(data[25], data[26])

        reading = { 
                 'previous_hop': prv,
                 'source': src,
                 'message_type': typ,
                 'id': mid,
                 'temperature': tmp,
                 'nitrate1': nit,
                 'nitrate2': 0,
                 'humidity': hum,
                 'battery_mvolts': bat,
                 'sensor_1_soil_dielectric': diel0,
                 'sensor_1_soil_conductivity': cond0,
                 'sensor_1_soil_temperature': temp0,
                 'sensor_2_soil_dielectric': diel1,
                 'sensor_2_soil_conductivity': cond1,
                 'sensor_2_soil_temperature': temp1
               }
        
        if self.log_mode == 0:
            self.logger.info(reading)
        elif self.log_mode == 1:
            print(reading)
        elif self.log_mode == 2:
            print('{} - {}/{} temp: {} humi: {}'.format(
                datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S,%f')[:-3], prv, src, tmp, hum))
        return reading

    def __decode_data(self, data):
        """
        Decode actual data (MESH_TYPE_DATA) or readings sent by the new nodes
        (used w/the updated mesh network)
        """

        # ===== Header =====
        
        # Previous Node (0)
        prv = data[0]
        # Source Node (2)
        src = data[0]
        # Message Type (4)
        typ = MessageType(data[4])
        # Message ID (5)
        mid = data[5]

        # ===== Data =====

        # Battery mvolts (10,11)
        bat = get_mvolts(data[10], data[11])
        # Nitrate 0 (12,13,14)
        nit0 = get_nitrate(data[12], data[13], data[14])
        # Nitrate 1 (15,16,17)
        nit1 = get_nitrate(data[15], data[16], data[17])
        # Humidity (18,19)
        hum = get_humidity(data[18], data[19])
        # Temperature (20,21)
        tmp = get_temp(data[20], data[21])
        
        # Soil Sensors (1-4)
        # Dielectric #1 (22, 23) 
        diel0 = conv_2digits(data[22], data[23])
        # Conductivity #1 (24, 25)
        cond0 = conv_2digits(data[24], data[25])
        # Temperature #1 (26, 27)
        temp0 = conv_2digits(data[26], data[27])
        
        # Dielectric #2 (28, 29) 
        diel1 = conv_2digits(data[28], data[29])
        # Conductivity #2 (30, 31)
        cond1 = conv_2digits(data[30], data[31])
        # Temperature #2 (32, 33)
        temp1 = conv_2digits(data[32], data[33])

        # Dielectric #2 (28, 29) 
        diel2 = conv_2digits(data[34], data[35])
        # Conductivity #2 (30, 31)
        cond2 = conv_2digits(data[36], data[37])
        # Temperature #2 (32, 33)
        temp2 = conv_2digits(data[38], data[39])

        # Dielectric #2 (28, 29) 
        diel3 = conv_2digits(data[40], data[41])
        # Conductivity #2 (30, 31)
        cond3 = conv_2digits(data[42], data[43])
        # Temperature #2 (32, 33)
        temp3 = conv_2digits(data[44], data[45])
        
        reading = { 
                 'previous_hop': prv,
                 'source': src,
                 'message_type': typ,
                 'id': mid,
                 'temperature': tmp,
                 'nitrate1': nit0,
                 'nitrate2': nit1,
                 'humidity': hum,
                 'battery_mvolts': bat,
                 'sensor_1_soil_dielectric':   diel0,
                 'sensor_1_soil_conductivity': cond0,
                 'sensor_1_soil_temperature':  temp0,
                 'sensor_2_soil_dielectric':   diel1,
                 'sensor_2_soil_conductivity': cond1,
                 'sensor_2_soil_temperature':  temp1,
                 'sensor_3_soil_dielectric':   diel2,
                 'sensor_3_soil_conductivity': cond2,
                 'sensor_3_soil_temperature':  temp2,
                 'sensor_4_soil_dielectric':   diel3,
                 'sensor_4_soil_conductivity': cond3,
                 'sensor_4_soil_temperature':  temp3
               }
        
        if self.log_mode == 0:
            self.logger.info(reading)
        elif self.log_mode == 1:
            print(reading)
        elif self.log_mode == 2:
            print('{} - {}/{} temp: {} humi: {}'.format(
                datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S,%f')[:-3], prv, src, tmp, hum))
        return reading

    def __decode_discovery_request(self, data):
        dest   = data[0]
        source = data[1]
        hops   = data[2]

        self.logger.info("ROUTE REQUEST: dest = {}, src = {}, hops = {}".format(dest, source, hops))

        return { 'source': source,
                 'num_hops': hops,
                 'dest': dest
               }

    def __decode_discovery_response(self, data):
        dest   = data[0]
        source = data[1]
        hops   = data[2]
        next_hop = data[3]

        self.logger.info("ROUTE RESPONSE: dest = {}, src = {}, hops = {}, next hops = {}".format( dest, source, hops, next_hops))

        return { 'source': source,
                 'num_hops': hops,
                 'next_hop': next_hop,
                 'dest': dest
               }

    def __decode_rt_gather(self, data):
        """
        Decode actual data (MESH_TYPE_RT_GATHER) with the details of the message
        sent by the node.
        """

        # ===== Header =====
        
        source  = data[0]
        entries = data[1]
        dest   = data[2]
        
        # ===== Data =====

        table = PrettyTable()
        table.field_names = ["Next Hop", "isNeighbor", "# of Hops", "State", "RSSI"]

        length = 5
        route_table = []
        for i in range(0, entries):
            xx = 5 + i * length
            inner_data  = []
            for j in range(0,5):
                # print("- inner_data[{}]={}".format(xx + j, data[xx + j]))
                inner_data.append(data[xx + j]) 

            state = ['Invalid',  'Valid'][inner_data[2]]
            rssi = conv_2digits_sign(inner_data[3], inner_data[4]) * 100
            table.add_row([i, inner_data[0], inner_data[1], state, rssi])
            route_table.append({ 'next_hop': i,
                                 'is_neighbor': inner_data[0],
                                 'num_hops': inner_data[1],
                                 'state': state,
                                 'rssi': rssi})

        self.logger.info("RT GATHER sent from node {} to node {}".format(source, dest))
        self.logger.info(route_table)

        if self.debug:
            print(table)

        return { 'source': source,
                 'num_entries': entries,
                 'dest': dest,
                 'route_table': route_table
               }

    def __decode_rt_report(self, data):

        # ===== Header =====

        source  = data[0]
        entries = data[1]
        hops   = data[2] 

        # ===== Data =====

        table = PrettyTable()
        table.field_names = ["isNeighbor", "# of Hops", "Next Hop", "State", "RSSI"]

        length = 5
        route_table = []
        for i in range(0, entries):
            xx = 5 + i * length
            inner_data  = []
            for j in range(0,5):
                # print("- inner_data[{}]={}".format(xx + j, data[xx + j]))
                inner_data.append(data[xx + j]) 

            state = ['Invalid',  'Valid'][inner_data[2]]
            rssi = conv_2digits_sign(inner_data[3], inner_data[4]) * 100
            table.add_row([inner_data[0], inner_data[1], i, state, rssi])
            route_table.append({ 'next_hop': i,
                                 'is_neighbor': inner_data[0],
                                 'num_hops': inner_data[1],
                                 'state': state,
                                 'rssi': rssi})

        self.logger.info("RT REPORT from node {}, # entries = {}".format(source, entries))
        self.logger.info(route_table)

        if self.debug:
            print(table)

        return { 'source': source,
                 'num_entries': entries,
                 'dest': dest,
                 'route_table': route_table
               }

    def __decode_rt_forward(self, data):

        # ===== Header =====

        source = data[0]
        num    = data[1]
        dest   = data[2]

        # ===== Data =====

        table = PrettyTable()
        table.field_names = ["Next Hop", "isNeighbor", "# of Hops", "State", "RSSI"]

        length = 5
        route_table = []
        for i in range(0, entries):
            xx = 5 + i * length
            inner_data  = []
            for j in range(0,5):
                # print("- inner_data[{}]={}".format(xx + j, data[xx + j]))
                inner_data.append(data[xx + j]) 

            state = ['Invalid',  'Valid'][inner_data[2]]
            rssi = conv_2digits_sign(inner_data[3], inner_data[4]) * 100
            table.add_row([i, inner_data[0], inner_data[1], state, rssi])
            route_table.append({ 'next_hop': i,
                                 'is_neighbor': inner_data[0],
                                 'num_hops': inner_data[1],
                                 'state': state,
                                 'rssi': rssi})

        self.logger.info("RT FORWARDING from {} to {}, # entries = {}".format(source, dest))
        self.logger.info(route_table)

        if self.debug:
            print(table)

        return { 'source': source,
                 'num_entries': entries,
                 'dest': dest,
                 'route_table': route_table
               }

    def __decode_hello(self, data):
        
        source = data[0]
        sender = data[1]
        hops =   data[2]

        print(" {} - originator = {}, sender = {}, hops = {}".format(
            datetime.datetime.now().isoformat(), source, sender, hops
            ))

    # -------------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------------

    def __hexArray2IntArray(self, offset, data):
        array = []
        for start in range(offset, len(data), 2):
            array.append(int (data[start:start+2], 16))
        return array

    def __is_MessageType_valid(self, type):
        if type > 10 or type < 0:
            return False
        else:
            return True