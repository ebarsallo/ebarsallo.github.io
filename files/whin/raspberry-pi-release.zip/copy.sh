#!/bin/bash

### Parameters


### Routines


### Main

# Sanity check
if [ "$1" != "" ]; then
    src=$1
else
    echo "Missing directory of the latest version"
    exit 1
fi

cp ${src}/*.py .
cp ${src}/*.json .

echo "Success"
exit 0
