#!/usr/bin/env python3
import re
import sys
import json
import subprocess

# Global Params
CONFIG_FILENAME = 'whin.json'
FILENAME = 'lora-gateway.zip'

def run_command(args, err = 'DEFAULT'):
    if err == 'DEFAULT':
        err = 'Error while trying to run command {}'.format(args[0])

    result = subprocess.run(args, stdout=subprocess.PIPE)
    output = result.stdout.splitlines()
    last = output[len(output)-1]
    last = last.decode('utf-8')

    if last.find('Success') < 0:
        raise Exception(err)
    return last

def update_version(curr, latest):
    curr_arr = curr.split('.')
    latest_arr = latest.split('.')

    for i in range(0,2):
        if int(latest_arr[i]) > int(curr_arr[i]):
            return True
    return False

def get_config(filename):
    try:
        json_data = json.loads(open(filename).read())
        return json_data

        url = json_data['update_url'] + "/" +FILENAME
        curr_version = json_data['version']
        
    except Exception as e:
        raise Exception('Error while trying to loads configuration')

def main():
    
     # load configuration
    curr = get_config(CONFIG_FILENAME)
    url = curr['update_url'] + "/" + FILENAME
 
    # download latest release
    last = run_command(['./update.sh', url], 'Error while trying to download latest version')

    # extract latest release
    try:
        found = re.search('Success: (.+)', last).group(1)

        latest = get_config(found + "/" + CONFIG_FILENAME)
        # print("{} vs {}".format(curr['version'], latest['version']))
        
        # Update version if the latest is greater then the current
        if update_version(curr['version'], latest['version']):
            print ("Updating...")
            run_command(['./copy.sh', found], 'Error while updating version')
        else:
            print ("The current version is the latest version, no need to update")

        run_command(['rm -rf %s' % found], 'Error while trying to remove temporal directory')

    except Exception as e:
        raise Exception('Error while trying to fetch the latest release')
    


if __name__ == '__main__':
    main()