#!/usr/bin/env python3
import sys
import json
import time
import serial
import logging
import datetime
import argparse
import traceback
import threading

from enum import Enum
from serial.threaded import LineReader, ReaderThread
from prettytable import PrettyTable
from hanging_threads import start_monitoring

from decoder import MessageDecoder
from utils import send_to_server, load_params, format_reading

# Global Params
import config as GV
CONFIG_FILENAME = 'config.json'

# Params
MAX_NODE = 99                       # Max node defined
BATCH_READINGS = 999999999999999                  # Batch limit used for uploading readings
LOG_MODE = 0                        # 0: Logger, 1: Console, 2: Raspberry-Pi (reduced) 
RANGE_TEST = 0                      # 0: false, 1: true

# Logging Settings
LOG_FILENAME = 'logs/collect-readings'
LOG_FORMAT='%(asctime)s - %(name)s - %(levelname)s - %(message)s'

# LoRa Settings
RADIO_MODE = "lora"
RADIO_FREQ = 915000000
RADIO_SPREADING_FACTOR = "sf7"      # Spreading Factor 
RADIO_BANDWIDTH = 125               # Bandwidth
RADIO_RX_BANDWIDTH = 125
RADIO_CODING_RATE = "4/5"           # Coding Rate
RADIO_CRC = "off"                   # CRC header disabled (should be on)
RADIO_SYNC_WORD = 12                # 0x12 Private, 0x34 public
RADIO_PREAMBLE = 8                  # Preamble Length
RADIO_IQ_INVERSION = "off"
RADIO_WATCHDOG_TIMEOUT = 2000       # ms (105000)
RADIO_POWER_OUT = 10
RADIO_RX_WINDOW_SIZE = 0            # contiuous mode

# Monitor thread
pmonitoring_thread = start_monitoring(seconds_frozen = 15 * 60, test_interval = 1000 * 60 * 10)

class PrintLines(LineReader):
    """
    PrintLines
    Handle connection with the LoStik device
    """

    def connection_made(self, transport):
        """
        Do connection w/LoStik device
        """
        self.set_logger()
        self.logger.info("connection made")
        self.transport = transport
        # self.send_cmd("sys factoryRESET")
        self.send_cmd('sys get ver')

        self.set_lora()
        # self.get_setup()

        self.send_cmd('mac pause')
        self.send_cmd('radio rx {}'.format(RADIO_RX_WINDOW_SIZE))

        self.send_cmd("sys set pindig GPIO10 0")

        # set attr
        self.debug = False         # if true, enable debugging output
        self.log_mode = LOG_MODE   # log mode
        self.msg = MessageDecoder(logger=self.logger, debug=True, log_mode=self.log_mode)

    def set_lora(self):
        """
        Set LoRa configuration
        """
        # set LoRa params
        self.send_cmd('mac pause')
        self.send_cmd('radio set mod {}'.format(RADIO_MODE))
        self.send_cmd('radio set freq {}'.format(RADIO_FREQ))
        self.send_cmd('radio set sf {}'.format(RADIO_SPREADING_FACTOR)) 
        self.send_cmd('radio set bw {}'.format(RADIO_BANDWIDTH)) 
        # self.send_cmd('radio set rxbw {}'.format(RADIO_RX_BANDWIDTH))
        self.send_cmd('radio set cr {}'.format(RADIO_CODING_RATE))
        self.send_cmd('radio set crc {}'.format(RADIO_CRC)) 
        self.send_cmd('radio set sync {}'.format(RADIO_SYNC_WORD)) 
        # self.send_cmd('radio set prlen {}'.format(RADIO_PREAMBLE))
        # self.send_cmd('radio set iqi {}'.format(RADIO_IQ_INVERSION)) 
        self.send_cmd('radio set wdt {}'.format(RADIO_WATCHDOG_TIMEOUT))      
        
        self.send_cmd('radio set pwr {}'.format(RADIO_POWER_OUT))

    def get_setup(self):
        """
        Print (console) the LoRa configuration of the setup
        """
        self.send_cmd('radio get mod')
        self.send_cmd('radio get freq')
        self.send_cmd('radio get sf')
        self.send_cmd('radio get bw')
        self.send_cmd('radio get cr')
        self.send_cmd('radio get crc')
        self.send_cmd('radio get prlen')
        self.send_cmd('radio get iqi')
        self.send_cmd('radio get sync')
        self.send_cmd('radio get wdt')

    def handle_line(self, data):
        """
        Handle each line (reponse) received by the device
        """
        if data == "ok" or data == 'busy':
            if self.debug:
                print(data)
            return
        if data == "radio_err":
            if self.debug:
                print (data)
            self.send_cmd('radio rx {}'.format(RADIO_RX_WINDOW_SIZE))
            return
        
        self.send_cmd("sys set pindig GPIO10 1", delay=0)
        threading.Thread(target=self.decode(data))
        # time.sleep(.1)
        self.send_cmd("sys set pindig GPIO10 0", delay=0.25)
        self.send_cmd('radio rx {}'.format(RADIO_RX_WINDOW_SIZE))

    def set_logger(self):
        """
        Create logger instance
        """
        logging.basicConfig(filename=LOG_FILENAME, filemode='w', level=logging.DEBUG, format=LOG_FORMAT)
        self.logger = logging.getLogger('collect-logger')

        # create console handler and set level to debug
        ch = logging.StreamHandler()
        ch.setLevel(logging.DEBUG)

        # create formatter
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

        # add formatter to ch
        ch.setFormatter(formatter)

        # add ch to logger
        self.logger.addHandler(ch)

    def decode(self, data):
        """
        Decode each line received by the device
        """

        try:
            if self.debug:
                self.logger.info(data)
            elif self.log_mode < 2:
                print("{} - {}".format(datetime.datetime.now().strftime("%Y%m%d-%H%M%S"), data))

            if RANGE_TEST == 1:
                return

            if data[0:8] == "radio_rx":
                rtn = self.msg.decode(data)

                # TODO. Upload data to server
                if 'message_type' in rtn:

                    # if node is higher than MAX, there is something WRONG with the 
                    # data received
                    if rtn['source'] > MAX_NODE:
                        raise Exception('source {} or previous {} are out of range'.format(
                            rtn['source'], rtn['previous_hop']))

                    if rtn['source'] == 0 and rtn['previous_hop'] != 0:
                        return

                    reading = format_reading(rtn, GV.WHIN_NODES)
                    GV.readings.append(reading)
                    # print("-- {} {}".format(len(GV.readings), BATCH_READINGS))

                    if ( len(GV.readings) > BATCH_READINGS ):
                        try:
                            send_to_server(GV.readings)
                            print('data uploaded')

                        except:
                            traceback.print_exc()
                            self.logger.exception('Communication Error')
                            self.logger.exception(data)

                        GV.readings = []
            else:
                pass
        
        except KeyboardInterrupt:
            exit()

        except:
            traceback.print_exc()
            self.logger.exception('Error while receiving the data')
            self.logger.exception(data)

    def connection_lost(self, exc):
        if exc:
            print(exc)
        print("port closed")

    def send_cmd(self, cmd, delay=.25):
        """
        Send command to LoStik device
        """

        # print(">" + cmd)
        self.transport.write(('%s\r\n' % cmd).encode('UTF-8'))
        time.sleep(delay)

def main():
    """
    Main routine
    """
    
    # load configuration
    try:
        json_data = json.loads(open(CONFIG_FILENAME).read())
        GV.WHIN_NODES = load_params(json_data)
        # print(GV.WHIN_NODES)
    except Exception as e:
        raise Exception('Error while trying to loads configuration')
    
    # init readings
    GV.readings = []

    # parse arguments
    parser = argparse.ArgumentParser(description='LoRa Radio mode receiver.')
    parser.add_argument('port', help="Serial port descriptor")
    args = parser.parse_args()

    # remove '/'' from port name (linux environment) 
    port = args.port
    while port.find('/') >= 0:
        pos = port.find('/')
        port = port[pos+1:]

    # logfile
    global LOG_FILENAME
    LOG_FILENAME='{}-{}_{}.log'.format(LOG_FILENAME, datetime.datetime.now().strftime("%Y%m%d-%H%M%S"), port)

    ser = serial.Serial(args.port, baudrate=57600)
    with ReaderThread(ser, PrintLines) as protocol:
        while(1):
            pass

if __name__ == '__main__':
    main()