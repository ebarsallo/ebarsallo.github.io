#!/usr/bin/env python3
import json
import time
import requests
import http.client

from threading import Timer
from enum import Enum

# Server Connection Parameters
SERVER = '128.46.73.96:5001'
# TIMEOUT in seconds
TIMEOUT = 10

# -------------------------------------------------------------------------------
# Thread / Server / Communication functions
# -------------------------------------------------------------------------------

def start_daemon(seconds, func, arguments):
    thread = Timer(seconds, func, arguments)
    #thread.daemon = True
    thread.start()

def format_reading(data, params):
    if data['source'] in params:
        location = params[data['source']]['place'] 
        building = params[data['source']]['geo_location']
    else:
        location = [0, 0]
        building = 'TEST' 

    reading = {
            'name': str(data['source']),
            'location': location,
            'timestamp': time.time(),
            'humidity': data['humidity'],
            'temp': data['temperature'],
            'batt-voltage': data['battery_mvolts'],
            'batt-level': int (battery_level_in_percent(data['battery_mvolts'])),
            'diel0': data['sensor_1_soil_dielectric'],
            'diel1': data['sensor_2_soil_dielectric'],
            'cond0': data['sensor_1_soil_conductivity'],
            'cond1': data['sensor_2_soil_conductivity'],
            'soil_temp0': data['sensor_1_soil_temperature'],
            'soil_temp1': data['sensor_2_soil_temperature'],
            'nitrate': data['nitrate1'],
            'nitrate1': data['nitrate2'],
            'building': building
          }
    return reading
    
def send_to_server(data):
    """
    Send the data (readings) to the Web Server

    :param data: list of dictionary (keys: name, temp, nitrate) 
    """
    js_data = json.dumps(data)
    #logger.debug(js_data)
    connection = http.client.HTTPConnection(SERVER, timeout=TIMEOUT)

    headers = {'Content-type': 'application/json'}
    connection.request('POST', '/', js_data, headers)

    response = connection.getresponse()
    print(json.loads(response.read().decode())['reply'])
    connection.close()

# -------------------------------------------------------------------------------
# Decode functions
# -------------------------------------------------------------------------------

def battery_level_in_percent(mvolts):

    if (mvolts >= 3000):
        battery_level = 100
    elif (mvolts > 2900):
        battery_level = 100 - ((3000 - mvolts) * 58) / 100
    elif (mvolts > 2740):
        battery_level = 42 - ((2900 - mvolts) * 24) / 160
    elif (mvolts > 2440):
        battery_level = 18 - ((2740 - mvolts) * 12) / 300
    elif (mvolts > 2100):
        battery_level = 6 - ((2440 - mvolts) * 6) / 340
    else:
        battery_level = 0

    return battery_level

def get_mvolts(high, low):
    batt = (high << 8 | low)
    batt = batt / 4096 * 3.6 * 2
    return batt * 1000
    
def sign_extend(val):
    # val is unsigned int now
    # print("converting " + "{0:b}".format(val)) 
    if val > 65535:
        raise Exception(str(val) + " is > 255")
    else:
        bits = 16
        sign_bit = 1 << (bits - 1)
        return (val & (sign_bit - 1)) - (val & sign_bit)

def get_nitrate(high, med, low):

    val = high << 16 | med << 8 | low
    if val and 0x00800000:
        val = ~val + 1;
        val = (val & 0x00FFFFFF)
        val = -1 * (2.4/16777216)*val
    else:
        val = (2.4/16777216) * val

    return val

def conv_2digits(high, low):
    return (high << 8 | low) / 100

def conv_2digits_sign(high, low):
    return sign_extend((high << 8) | low) / 100

def get_temp(high, low):
   # print("high 8 bits: " + "{0:b}".format(high))
   # print("low 8 bits: " + "{0:b}".format(low))
   # print("high 8 bits after shift by 8: " + "{0:b}".format(high << 8))
    return sign_extend((high << 8) | low) / 100

def get_humidity(high, low):
    return conv_2digits(high, low)

def get_dielec(high, low):
    return conv_2digits(high, low)

# -------------------------------------------------------------------------------
# Decode functions
# -------------------------------------------------------------------------------

def load_params(json_data):
  places = {}
  nodes = {}

  for json_place in json_data['places']:
    places[json_place['code']] = json_place['name']

  for json_node in json_data['data']:
    nodes[json_node['node']] = {
        'place': places[json_node['place']] if json_node['place'] in places else 'TEST',
        'geo_location': json_node['geo_location']
    }

  return nodes

